package com.happyheng.service;

public interface RegisterService {
	
	public int register(String userName, String passWord, String nickName);
}
