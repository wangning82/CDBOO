package com.happyheng.service.impl;

/**
 * 逻辑处理类的基类
 * 
 * @author liuheng
 *
 */
public class BaseService {
	// 请求成功的返回值
	public static int RESULT_CODE_SUCCESS = 0;
	// 请求失败的返回值
	public static int RESULT_CODE_ERROR = 100;

}
