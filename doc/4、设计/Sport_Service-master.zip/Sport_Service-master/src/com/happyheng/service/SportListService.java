package com.happyheng.service;

import com.happyheng.entity.result.SportListResult;

public interface SportListService {
	public SportListResult getSportList(String userKey);
}
