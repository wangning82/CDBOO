package com.happyheng.test;

import java.sql.Connection;

import com.happyheng.dao.UserDao;
import com.happyheng.utils.ConnectionFactory;

public class ConnectionTest {

	public static void main(String[] args) throws Exception{
//		// TODO Auto-generated method stub
//		ConnectionFactory factory = ConnectionFactory.getInstance();
//		Connection connection = factory.makeConnection();
//		
//		User user = new User();
//		user.setName("happyheng1");
//		user.setPassword("123456");
//		user.setNickname("happyhappy1");
//		
//		UserDao userDao = new UserDaoImplement();
		//int code = userDao.save(connection, user);
		
		//System.out.println("返回的code为"+code);
	}

}
