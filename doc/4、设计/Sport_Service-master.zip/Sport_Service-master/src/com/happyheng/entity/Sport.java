package com.happyheng.entity;

public class Sport extends IdEntity {
	private int  userid;

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}
	
}
