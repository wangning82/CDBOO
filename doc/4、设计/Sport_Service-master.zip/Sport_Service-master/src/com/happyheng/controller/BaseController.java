package com.happyheng.controller;

public class BaseController {
	protected static final String RESULT_KEY = "result";
	private static final String APPLICATION_XML = "applicationContext.xml";

//	protected ApplicationContext context;
//	
//	public BaseController(){
////		context = new ClassPathXmlApplicationContext(APPLICATION_XML);
//	}
}
